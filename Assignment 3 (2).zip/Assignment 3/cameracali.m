% Given the pixel coordinates and the associated 3D coordinates as input,
% we estimate the intrinsic camera parameters or the K matrix. Along the
% way, we also figure out the extrinsic parameters in R and T and display 
% those. Note: the returned matrix is the normalized K.
function K = cameracali(Coord2d, Coord3d)
M = []; 
% Below line gets the number of feature points to process or loop through.
numFeaturePoints = size(Coord2d, 2);
% For each feature point, 2 rows are outputted, where according to the 
% formulas, one row is related to the x pixel coordinate while other is 
% to the y pixel coordinate. 
for i=1:numFeaturePoints
    xCoord = -1*Coord2d(1, i);
    xX = xCoord * Coord3d(1, i);
    yY = xCoord * Coord3d(2, i);
    zZ = xCoord * Coord3d(3, i);
%     This is relating to this formula where 
%  mii = (Xi, Yi, Zi, 1, 0, 0, 0, 0, -xi'Xi, -xi'Yi, -xi'Zi, -xi') where 
% Xi, Yi, and Zi are the Homogenous 3D coordinates while xi' is the 
% 2d x coordinate part of pixel
    mX = [Coord3d(1, i) Coord3d(2, i) Coord3d(3, i) 1 0 0 0 0 xX yY zZ xCoord];
    yCoord = -1 * Coord2d(2, i);
    yX = yCoord * Coord3d(1, i);
    yY = yCoord * Coord3d(2, i);
    yZ = yCoord * Coord3d(3, i);
    
%     This is relating to this formula where
% mii = (0, 0, 0, 0, Xi, Yi, Zi, 1, -yiXi, -yiYi, -yiZi, -yi')
% Xi, Yi, and Zi are the Homogenous 3D coordinates while xi' is the 
% 2d x coordinate part of pixel
    mY = [0 0 0 0 Coord3d(1, i) Coord3d(2, i) Coord3d(3, i) 1 yX yY yZ yCoord];
    M = [M; mX; mY];
end

% Below line gets eigenvectors and values of M times M tranpose
[eigenVectors, eigenValues] = eig(M'*M);
% This gives minimum eigenvector of M times M transpose and so this is 
% our pi. Now just have to reshape accordingly which is done in following
% loop.

pi = eigenVectors(:,1);
realPi = [];
% Simple loop where we create a matrix that is a 3 by 4 version of 
% the column pi we found above. 
index = 0;
for i=1:3
    realPi = [realPi; pi(index + 1,1) pi(index + 2,1) pi(index + 3,1) pi(index + 4,1)];
    index = index + 4;
end

    

% This is what K * R equals.
kR = [realPi(1, 1:3); realPi(2, 1:3); realPi(3, 1:3)];

% Used to change sign is determinant is less than 0.
if det(kR) < 0
    kR = kR * -1;
end

% https://math.stackexchange.com/questions/1640695/rq-decomposition
% The above is website where I found procedure for doing the RQ 
% decompostion and found way of extracting R and K. Used the diag and 
% sign methods to ensure that values along diagonal of K are positive
% and that the R value determinant is 1 instead of -1.
P = [0 0 1; 0 1 0; 1 0 0];
reversedKR = P * kR;
[notR, notK] = qr(reversedKR');
R = P * notR';
K = P * notK' * P;
R = diag(sign(diag(K))) * R; 
K = K * diag(sign(diag(K)));
R  % display the R matrix
K  % display the un normalized K matrix here.


% Just used formula from notes for calculating Translation matrix.
T = inv(K) * [realPi(1, 4); realPi(2, 4); realPi(3, 4)];
T % Translation matrix is displayed here.
K = K / K(3, 3); % Normalized K here.
K % Intrinsic Camera parameters matrix K is outputted here
end