% Assignment 3
% Name: Viren Velacheri, EID: vv6898
% Slip days: 2
% Basically did 3 different configurations of keypoints. Select 10 each
% time and 
calibrationPicture = "Calibration.jpg";
calibrationImage = imread(calibrationPicture);
% For this first configuration of points, the points I select are pretty
% widespread on the cube.
figure;
imshow(calibrationImage);
hold on;
[x, y] = ginput(10);
coord2D = [x y];
coord2D = coord2D';
coord3D = [0 0 0; 0 2 0; 4 0 0; 0 0 4; 5 3 0; 0 3 5; 2 0 2; 5 0 1; 2 0 4; 0 3 7];
coord3D = coord3D';
figure("name", "1st Configuration of KeyPoints","NumberTitle", "off");
imshow(calibrationImage);
hold on;
plot(x, y, 'r+');
k = cameracali(coord2D, coord3D);

% For this second configuration of points, I just picked them across the 
% axes of the cube.
figure;
imshow(calibrationImage);
[x, y] = ginput(10);
coord2D = [x y];
coord2D = coord2D';
coord3D = [0 0 0; 0 0 1; 0 0 2; 0 0 3; 0 1 0; 0 2 0; 0 3 0; 1 0 0; 2 0 0; 3 0 0];
coord3D = coord3D';
figure("name", "2nd Configuration of KeyPoints","NumberTitle", "off");
imshow(calibrationImage);
hold on;
plot(x, y, 'r+');
k = cameracali(coord2D, coord3D);

% For this last configuration of points, I just picked points on the 
% from the origin and so weren't on the axes of the cube at all. 
figure;
imshow(calibrationImage);
[x, y] = ginput(10);
coord2D = [x y];
coord2D = coord2D';
coord3D = [0 0 0; 0 1 1; 0 2 2; 0 3 3; 1 1 0; 2 2 0; 3 3 0; 1 0 1; 2 0 2; 3 0 3];
coord3D = coord3D';
figure("name", "3rd Configuration of KeyPoints","NumberTitle", "off");
imshow(calibrationImage);
hold on;
plot(x, y, 'r+');
k = cameracali(coord2D, coord3D);

% Note: All results for these can be seen in pdf.